#2017111366 정보보호학과 이시영
#레시피를 참고하여 요리를 할 수 있도록 도와줄 수 있도록 하는 페이지를 만드는 걸 목표로 하였다!

from tkinter import*

w=Tk()
w.title("기말과제")
w.geometry("1100x1050")

#함수정의

#r1~r5까지의 value값에 따라 출력되는 게 다르도록 설정하는 함수를 정의하였다.

def click_me():
    if var.get()==1:
        label0.configure(text="재료\n\n""호박고구마 300g, 양파(중소)1/3, 파프리카 1/4\n""옥수수통조림 반줌, 모짜렐라치즈, 체다치즈(선택), 식용유\n\n""소스 : 생크림(우유) 2큰술, 설탕1.5큰술, 소금 한꼬집\n\n""(1큰술 = 15ml 계량스푼)")
        label1.configure(image=photo6)
        label2.configure(text="고구마는 익기 좋도록 껍질을 제거해 듬성듬성 썰어주고\n"" 양파와 파프리카는 잘게 썰어주세요.")
    elif var.get()==2:
        label0.configure(text="재료\n\n""떡 250g, 훈제 오리고기 120g, 참기름 0.5큰술\n""양파(중) 1/3, 파프리카 1/3, 대파 조금\n\n""소스 : 간장 1큰술, 굴소스 1큰술, 맛술 1큰술, 물 1큰술\n""올리고당 1큰술, 다진마늘 0.5큰술, 후추 톡톡\n\n""(1큰술 = 15ml 계량스푼)")
        label1.configure(image=photo13)
        label2.configure(text="훈제 오리고기는 먹기 좋은 크기로 썰고\n""양파와 파프리카는 채 썰어줍니다.\n""대파는 어슷하게 송송 썰어주었어요.\n\n""버섯이나 당근, 피망같은 자투리 채소들을 활용해도 좋아요!")
    elif var.get()==3:
        label0.configure(text="재료\n\n""우동사리 1팩, 청피망 1/4, 홍피망 1/4, 양파 1/3\n""비엔나소시지 한줌, 식용유, 참기름 0.5큰술\n\n""소스 : 기꼬만 혼쯔유 1큰술, 진간장 1큰술, 맛술 1큰술\n""올리고당 1큰술, 다진마늘 0.5큰술, 후추 톡톡\n\n""(1큰술 = 15ml 계량스푼)")
        label1.configure(image=photo21)
        label2.configure(text="피망, 양파는 채 썰고\n""소시지는 얄팍하게 썰어줍니다.\n")
    elif var.get()==4:
        label0.configure(text="재료\n\n""후라이드 치킨, 달걀 2개, 밥 1.5~2공기, 파 조금\n""우유 3큰술, 양파 1/2, 마요네즈, 간장 2큰술, 식용유\n\n""소스 : 올리고당 1큰술, 맛술 1큰술, 소금\n\n""(1큰술 = 15ml 계량스푼)")
        label1.configure(image=photo28)
        label2.configure(text="뼈가 있는 치킨이라면 뼈를 발라주고\n""먹기 좋은 크기로 아담하게 손질합니다.\n")
    else :
        label0.configure(text="재료\n\n""미니 크로아상, 슬라이스 체다치즈\n""슬라이스 햄, 치커리, 계란 2개, 우유 5큰술, 식용유\n\n""소스 : 소금, 마요네즈, 허니 머스타드\n\n""(1큰술 = 15ml 계량스푼)")
        label1.configure(image=photo35)
        label2.configure(text="미니 크로아상을 준비해주세요.\n""준비한 크로아상은 끝부분은 살짝 남기고 반으로 잘라줍니다.\n")


#각각의 버튼마다 실행되는 함수를 다르게 하여 뜨는 화면이 바뀌도록 설정하였다.
def click():
    label1.configure(image=photo6)
    label2.configure(text="고구마는 익기 좋도록 껍질을 제거해 듬성듬성 썰어주고\n"" 양파와 파프리카는 잘게 썰어주세요.")

def click1():
    label1.configure(image=photo7)
    label2.configure(text="끓는 물에 넣어 젓가락으로 찔러\n포옥 들어갈 정도로 충분히 삶아줍니다.")

def click2():
    label1.configure(image=photo8)
    label2.configure(text="물기를 털며 건져내고 뜨거운 상태에서\n포크를 이용해 곱게 으깨주세요.\n이어서 생크림(우유) 2큰술, 설탕 1.5큰술\n소금 한 꼬집을 넣어 고르게 섞어줍니다.")

def click3():
    label1.configure(image=photo9)
    label2.configure(text="야채들과 물기를 털어낸 옥수수 통조림은\n팬에 식용유를 살짝 두른 후,\n수분을 날리며 볶아 준비합니다.")

def click4():
    label1.configure(image=photo10)
    label2.configure(text="볶아진 야채를 넣고 가볍게 섞어주세요.")

def click5():
    label1.configure(image=photo11)
    label2.configure(text="오븐 전용 그릇에 으깬 고구마를 담고\n모짜렐라 치즈와 체다치즈를 적당히 올려\n190도 예열된 오븐에서 12분 정도 구워줍니다.\n(전자레인지로 만들어도 좋아요!)")

def click6():
    label1.configure(image=photo12)
    label2.configure(text="그럼 이제 고구마 그라탕이 완성됩니다.\n 다들 いただきます!")        
        
#main
#우선 제일 위에 뜨는 제목을 설정하는 소스이다.
labelText=Label(w, text="이따다끼마쓰", fg="orange", font=("1훈프로방스 R",50))

var=IntVar()

#각각의 포토들의 변수들을 정의해주었다.
photo1=PhotoImage(file="gif/1.gif")
photo2=PhotoImage(file="gif/2.gif")
photo3=PhotoImage(file="gif/3.gif")
photo4=PhotoImage(file="gif/4.gif")
photo5=PhotoImage(file="gif/5.gif")

photo6=PhotoImage(file="gif/고구마1(수정).gif")
photo7=PhotoImage(file="gif/고구마2(수정).gif")
photo8=PhotoImage(file="gif/고구마3(수정).gif")
photo9=PhotoImage(file="gif/고구마4(수정).gif")
photo10=PhotoImage(file="gif/고구마5(수정).gif")
photo11=PhotoImage(file="gif/고구마6(수정).gif")
photo12=PhotoImage(file="gif/고구마7(수정).gif")

photo13=PhotoImage(file="gif/떡볶이1(수정).gif")
photo21=PhotoImage(file="gif/볶음우동1(수정).gif")
photo28=PhotoImage(file="gif/치킨마요1(수정).gif")
photo35=PhotoImage(file="gif/크로아상1(수정).gif")


#메뉴가 5개이기 때문에 라디오 버튼 변수를 5개 정의하고 눌리면 메뉴에 따른 레시피가 뜨도록 설정하였다.
r1=Radiobutton(w, image=photo1, variable=var, value=1, command=click_me)
r2=Radiobutton(w, image=photo2, variable=var, value=2, command=click_me)
r3=Radiobutton(w, image=photo3, variable=var, value=3, command=click_me)
r4=Radiobutton(w, image=photo4, variable=var, value=4, command=click_me)
r5=Radiobutton(w, image=photo5, variable=var, value=5, command=click_me)

#버튼을 각각 정의해주었다.
button1=Button(w, text="1단계", command=click)
button2=Button(w, text="2단계", command=click1)
button3=Button(w, text="3단계", command=click2)
button4=Button(w, text="4단계", command=click3)
button5=Button(w, text="5단계", command=click4)
button6=Button(w, text="6단계", command=click5)
button7=Button(w, text="7단계", command=click6)

#label 변수들을 정의내려 준 부분이다. 각각 폰트를 적용하고 글씨크기를 조절하여 가독성이 좋게 하였다.
label0=Label(w, bg="orange", font=("THE홍차왕자 소녀",17))
label1=Label(w)
label2=Label(w, font=("THE홍차왕자 소녀",17))

#여기서 부터 아래까진 모두 위치를 설정해준 부분이다. pack을 사용하는 대신 place를 사용해 원하는 위치에 있을 수 있도록 설정하였다.
labelText.pack(anchor=CENTER)
r1.place(x=30, y=80)
r2.place(x=230, y=80)
r3.place(x=430, y=80)
r4.place(x=630, y=80)
r5.place(x=830, y=80)

label0.place(x=370, y=200)
label1.place(x=100, y=500)
label2.place(x=700, y=650)

button1.place(x=225, y=900)
button2.place(x=325, y=900)
button3.place(x=425, y=900)
button4.place(x=525, y=900)
button5.place(x=625, y=900)
button6.place(x=725, y=900)
button7.place(x=825, y=900)



w.mainloop()

#버튼, 사진, 글, 재료 목록이 한 번에 뜨도록 하고 싶었지만 아직 역량이 부족해 그것까진 하지 못했다. 그게 아쉬운 부분이지만 그래도 최선을 다해서 페이지를 만든 것 같아서 아쉬움보단 뿌듯함이 더 큰 것 같다.
